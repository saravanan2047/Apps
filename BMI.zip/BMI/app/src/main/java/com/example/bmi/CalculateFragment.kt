package com.example.bmi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import com.example.bmi.databinding.FragmentCalculateBinding


class CalculateFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: FragmentCalculateBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_calculate, container, false)
        val viewModel = MainViewModel()
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        val weight = viewModel.weight
        val height = viewModel.height
        binding.button.setOnClickListener { view ->
            val bmi = viewModel.calculateBmi()
            if (bmi == 0.0) {
                Toast.makeText(activity, "Enter Values First!!", Toast.LENGTH_SHORT).show()
            }
            if (bmi < 18.5 && bmi > 0.0) {
                Navigation.findNavController(view)
                    .navigate(CalculateFragmentDirections.actionCalculateFragmentToLeanFragment2(bmi.toFloat()))//action_calculateFragment_to_leanFragment2)
            } else if (bmi >= 18.5 && bmi < 25.0) {
                Navigation.findNavController(view).navigate(
                    CalculateFragmentDirections.actionCalculateFragmentToHealthyFragment(bmi.toFloat())
                )
            } else if (bmi >= 25.0 && bmi < 30.0) {
                Navigation.findNavController(view).navigate(
                    CalculateFragmentDirections.actionCalculateFragmentToOverWeightFragment(bmi.toFloat())
                )
            } else if (bmi >= 30.0 && bmi < 40) {
                Navigation.findNavController(view)
                    .navigate(CalculateFragmentDirections.actionCalculateFragmentToObeseFragment(bmi.toFloat()))
            } else {
                Toast.makeText(
                    activity,
                    "Highly Obese Get Training Right Away...!!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        return binding.root
    }
}


//class CalculateFragment : Fragment() {
//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        val binding: FragmentCalculateBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_calculate, container, false)
//        val viewModel = MainViewModel()
//        binding.viewModel = viewModel
//        binding.lifecycleOwner = this
//
//        binding.button.setOnClickListener { view ->
//            val bmi = viewModel.calculateBmi()
//            if (bmi == 0.0) {
//                Toast.makeText(activity, "Enter Values First!!", Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
//
//            val action = when {
//                bmi < 18.5 -> CalculateFragmentDirections.actionCalculateFragmentToLeanFragment2(bmi)
//                bmi < 25.0 -> CalculateFragmentDirections.actionCalculateFragmentToHealthyFragment(bmi)
//                bmi < 30.0 -> CalculateFragmentDirections.actionCalculateFragmentToOverWeightFragment(bmi)
//                bmi < 40.0 -> CalculateFragmentDirections.actionCalculateFragmentToObeseFragment(bmi)
//                else -> return@setOnClickListener
//            }
//
//            Navigation.findNavController(view).navigate(action)
//        }
//        return binding.root
//    }
//}
