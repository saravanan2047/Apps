package com.example.bmi

import androidx.lifecycle.ViewModel

class MainViewModel:ViewModel() {
    var height: String=""
    var weight:  String=""
    var res: Double=0.0
  
    fun calculateBmi():Double{
        if(height.isNotEmpty() && weight.isNotEmpty()) {
            var h = height.toDouble()
            var w = weight.toDouble()

            val heightInMeters = h / 100.0
            res= w / (heightInMeters * heightInMeters)
        }

        return res
    }
}

