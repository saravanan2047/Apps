package com.example.bmi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.example.bmi.databinding.FragmentHealthyBinding
import com.example.bmi.databinding.FragmentOverWeightBinding


class OverWeightFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: FragmentOverWeightBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_over_weight, container, false)
            binding.resultText.text= arguments?.getFloat("bmi").toString()
        return binding.root

    }
}