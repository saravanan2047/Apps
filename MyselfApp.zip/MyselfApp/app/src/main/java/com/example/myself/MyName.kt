package com.example.myself

data class MyName ( var name: String = "",
                    var nickname: String = "")