package com.example.basicform

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.basicform.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding //  creating object of binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.submit.setOnClickListener {
            submit(it)
        }
//        setContentView(R.layout.activity_main)
//          findViewById<Button>(R.id.done_button).setOnClickListener {
//            addNickname(it)
//        }
    }

    private fun submit(view : View)
    {
        binding.apply{
//        val value: String = editText.getText().toString()
            val userName=editName.text.toString()
            val userPhone=editPhone.text.toString()
            val userEmail=editEmail.text.toString()

            name.setText(userName)
            email.setText(userEmail)
            phoneNumber.setText(userPhone)
            verify.setText("Verify Your Details")
            success.setText("Please Login...")
            submit.visibility=View.INVISIBLE
            editName.visibility=View.GONE
            editPhone.visibility=View.GONE
            editEmail.visibility=View.GONE
            Title.visibility=View.GONE

        }
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)



    }
}