package com.example.colorapp

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        setListeners()
    }

    private fun setListeners() {
        val clickableViews: List<View>
                = listOf(findViewById(R.id.box_one),findViewById(R.id.box_two),findViewById(R.id.box_three),
            findViewById(R.id.box_four),findViewById(R.id.box_five),
            findViewById(R.id.button_red),findViewById(R.id.button_blue),findViewById(R.id.button_green),findViewById(R.id.main_layout))

        for(item in clickableViews)
        {
            item.setOnClickListener()
            {
                makeColored(it)
            }
        }
    }

    @SuppressLint("ResourceAsColor")
    private fun makeColored(view: View) {
        when (view.id) {

            // Boxes using Color class colors for background
            R.id.box_one -> view.setBackgroundColor(Color.DKGRAY)
            R.id.box_two -> view.setBackgroundColor(Color.GRAY)

            // Boxes using Android color resources for background
            R.id.box_three -> view.setBackgroundResource(R.color.yellow)
            R.id.box_four -> view.setBackgroundResource(android.R.color.holo_orange_light)
            R.id.box_five-> view.setBackgroundResource(android.R.color.holo_green_light)

            R.id.button_red -> findViewById<View?>(R.id.box_one).setBackgroundResource(R.color.orange)
            R.id.button_blue -> findViewById<View?>(R.id.box_two).setBackgroundResource(R.color.pinkcolor)
            R.id.button_green -> findViewById<View?>(R.id.box_three).setBackgroundResource(R.color.green)

            else ->view.setBackgroundColor(Color.LTGRAY)
        }
    }
}