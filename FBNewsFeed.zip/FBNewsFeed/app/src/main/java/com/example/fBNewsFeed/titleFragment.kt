package com.example.fBNewsFeed

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.example.fBNewsFeed.databinding.FragmentTitleBinding


class titleFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding: FragmentTitleBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_title,container,false)
        val viewModel = MainViewModel()
        binding.viewModel=viewModel
        binding.lifecycleOwner = this

        binding.login.setOnClickListener { view ->
            if (viewModel.isEmailValid() && viewModel.isPasswordValid()) {
                val email = viewModel.email
                val password = viewModel.password
                Navigation.findNavController(view).navigate(titleFragmentDirections.actionTitleFragmentToNewsFragment())
            } else {
                Toast.makeText(activity, "Invalid input. Please check email and password", Toast.LENGTH_SHORT).show()
            }
        }
        return binding.root
    }
}