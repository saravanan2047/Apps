package com.example.fBNewsFeed

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        val launcherImageView = findViewById<ImageView>(R.id.launcher_iv)
        launcherImageView.alpha = 0f
        launcherImageView.animate().setDuration(1700).alpha(1f).withEndAction {
            val i= Intent(this,MainActivity::class.java)
            startActivity(i)
            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
            finish()
        }
        }
}
