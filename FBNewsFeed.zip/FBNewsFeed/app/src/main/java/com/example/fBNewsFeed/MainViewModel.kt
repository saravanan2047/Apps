package com.example.fBNewsFeed

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    var email: String = ""
    var password: String = ""
    fun isEmailValid(): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isPasswordValid(): Boolean {
        return password.length >= 6
    }
}